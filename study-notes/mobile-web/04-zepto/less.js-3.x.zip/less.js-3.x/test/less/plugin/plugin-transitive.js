functions.addMultiple({
    "test-transitive" : function() {
        var anon = new tree.Anonymous( "transitive" );
        return anon;
    }
});
