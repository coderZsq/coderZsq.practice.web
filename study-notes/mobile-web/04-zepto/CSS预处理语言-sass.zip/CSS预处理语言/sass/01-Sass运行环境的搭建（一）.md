# 1.Sass运行环境的搭建（一）

## 1.什么是Sass?

**Sass** 是最早的 **CSS 预处理语言**，有比 **LESS** 更为强大的功能，不过其一开始的缩进式语法（Sass 老版本语法）并不能被大众接受，不过由于其强大的功能和 Ruby on Rails 的大力推动，还是有很多开发者选择了 Sass。

**Sass** 是采用**Ruby**语言编写的一款 **CSS 预处理语言**，它诞生于**2007**年，是最大的成熟的 **CSS 预处理语言**。最初它是为了配合 HAML（一种缩进式 HTML 预编译器）而设计的，因此有着和 HTML 一样的缩进式风格。



## 2.Sass 和 SCSS 有什么区别？

**Sass** 和 **SCSS** 其实是同一种东西，我们平时都称之为 **Sass**，两者之间不同之处有以下两点：

- 文件扩展名不同：

  Sass 是以“.sass”后缀为扩展名，而 SCSS 是以“.scss”后缀为扩展名


- 语法书写方式不同：

  Sass 是以严格的缩进式语法规则来书写，不带大括号({})和分号(;)，

  SCSS 的语法书写和我们的 CSS 语法书写方式非常类似。

例如：

sass语法：

```scss
$bgColor:green
$w:300px
$h:300px

.test1
  background-color: $bgColor
  width: $w
  height: $h
```

scss语法：

```scss
$bgColor:green;
$w:300px
$h:300px

div{
  background-color: $bgColor;
  height: $h;
  width: $w;
}
```

编译后的结果：

```scss
div {
  background-color: green;
  height: 300px;
  width: 300px; }
```



## 3.Sass在window下的安装

### 1.安装 Ruby

在 Windows 平台下安装 Ruby 需要先有 Ruby 安装包，大家可以到 Ruby 的官网（http://rubyinstaller.org/downloads）下载对应需要的 Ruby 版本。

1. 下载Ruby

   ![](1.png)

2. 安装过程中默认勾选第一、二个选项（如果第一个不选，就会出现编译时找不到Ruby环境的情况）

   ​

   ![](2.png)

   ​

3. 安装好 Ruby 之后就可以使用gem的命令

   打开电脑的命令终端：

   ```
   ruby -v  // 查看ruby的版本
   gem -v   //查看gem的版本
   ```


### 2.安装 Sass

1. 打开电脑的命令终端，输入下面的命令：

   ```
   gem install sass
   ```

   ​

2. 查看sass的版本

   ```
   sass -v //查看sass的版本
   ```


## 4.Sass使用方式一

### 1.sass语法

![](3.png)

- 编写01-index.html

  ```html
  <!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <title>Title</title>
  </head>
  <body>

  <diV class="test1"></diV>
  </body>
  </html>
  ```

  ​

- 编写index.sass

  sass文件在编译时不能出现有中文（编译时要不下面的中文删除）

  ```scss
  //使用$定义变量，语句结束不使用分号
  $bgColor:red
  $w:300px
  $h:300px

  // css使用tab缩进 ，语句结束不使用分号
  .test1
    background: $bgColor
    width: $w
    height: $h
  ```

  ​

- 终端进入index.sass文件夹下，使用sass命令编译

  ```
  sass index.sass index.css  // 将index.sass 编译为index.css
  ```

  ![](4.png)

### 2.scss语法

![](5.png)

- 编写index.sass

  ```scss
  /*scss语法还是使用$定义变量，结束需要分号*/
  $bgColor:green;
  $w:200px;

  div{
    background-color: $bgColor;
    height: $w;
    width: $w;
  }
  ```

  ​

- 终端进入index.scss文件夹下，使用sass命令编译

  ```
  sass  index.scss  index.css // 将index.scss 编译为index.css
  ```

  ![](6.png)

## 5.Sass使用方式二

### 1.scss语法

使用koala软件来实现自动编译（ scss - > css ）

参考文献：http://www.w3cplus.com/preprocessor/sass-gui-tool-koala.html

- 安装Koala，并打开Koala

  ![](7.png)


- 点击左上角的+来添加02-demo项目

  ![](8.png)

  ​

- 执行编译项目中的scss文件

> 注意：scss文件必须放在名字为sass的文件夹中，否则编译失败

![](9.png)

- 编译后的结果

  ![](10.png)

































