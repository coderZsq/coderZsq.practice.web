export const CHANGE_ARTICLES = 'article/CHANGE_ARTICLES';
export const CHANGE_ARTICLE = 'article/CHANGE_ARTICLE';
