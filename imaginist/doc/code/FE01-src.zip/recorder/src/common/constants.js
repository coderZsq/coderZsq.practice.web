export const HOME_ARTICLES_SIZE = 2;
