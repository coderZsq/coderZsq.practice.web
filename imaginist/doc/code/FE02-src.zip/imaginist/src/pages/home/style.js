import styled from 'styled-components';

export const SQHomePageWrapper = styled.div``;
